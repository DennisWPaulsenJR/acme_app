<!doctype html>
<html lang="en">
<head>
    <title>registration | acme</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" type="text/css" href="../css/primary.css"/>
</head>

<body>
    <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php';?>
    </header>
    <div id="formContainer">
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/regForm.php';?>
    </div>

   
</body>
</html>