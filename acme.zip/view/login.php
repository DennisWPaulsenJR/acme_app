<!DOCTYPE html>
<head>
    <title>login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--example media query link-->
    <link rel="stylesheet" type="text/css" href="../css/primary.css">

</head>

    <body>

        <header>    
            <?php include $_SERVER['DOCUMENT_ROOT'] . '/acme/common/header.php'; ?>
        </header>
        
        <div id="formContainer">
            <?php include $_SERVER['DOCUMENT_ROOT'] . '../acme/common/loginForm.php'; ?>
         </div>
    </body>

