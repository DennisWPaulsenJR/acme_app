
    <div class="main_content">
        <h1>welcome to acme</h1>

        <div class="container">
            <img id="hero" src="../images/site/rocketfeature.jpg" alt="acme rockets image"/>
            <div class="container_right">
                <ul>
                    <li><h2>Acme Rocket</h2></li>
                    <li>Quick lighting fuse</li>
                    <li>NHTSA approved seat belts</li>
                    <li>Mobile launch stand included</li>
                    <li><a href="/acme/cart/"><img id="actionbtn" alt="Add to cart button" src="../images/site/iwantit.gif"></a></li>
                </ul>
            </div>
        </div>

        <div class="menu">
            <ul>
                <li>"I don't know how I ever caught roadrunners before this." (4/5)</li>
                <li>"That thing was fast!" (4/5)</li>
                <li>"Talk about fast delivery." (5/5)</li>
                <li>"I didn't even have to pull the meat apart." (4.5/5)</li>
                <li>"I'm on my thirtieth one. I love these things!" (5/5)</li>
            </ul>

        </div>

    </div>