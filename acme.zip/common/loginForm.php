
<?php if (isset($message)) {
    echo $message;
}?>
            <form class="login" action="../accounts/My_account_controller.php">
                <label for="email">email</label>
                <br>
                <input type="email" />
                <br>
                <label for="password">password</label>
                <br>
                <input type="password" />
                <br>
                <br>
                <div class="buttons">
                <input type="submit" value="login"/>
                
                <br>
                <br>
                <label for="login_button">become a Member</label>
                <input type="button" onclick="window.location.href='registration.php'" 
                       value="register"/>
                <input type="reset" value="reset"/>
                </div>
            </form>
        
        