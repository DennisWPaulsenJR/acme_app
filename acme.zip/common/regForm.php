
<?php if (isset($message)) {
    echo $message;
}?>

<div id="regFormContainer">
    <form action="../accounts/My_account_controller.php" method="post">

        <p>
            <label for="firstName">first name:</label><br>
            <input type="text" id="first_name" name="ClientFirstName"/>
        </p>
        <p> 
            <label for="lastName">last name:</label><br>
            <input type="text" id="last_name" name="ClientLastName"/>
        </p>
        <p>
            <label for="email">email:</label><br>
            <input type="email" id="email" name="ClientEmail"/>
        </p>
        <p>
            <label for="password">password:</label><br>
            <input type="password" id="password" name="ClientPassword"/>
        </p>
        <p>
            <input type="reset" name="reset" value="reset" />
            <input type="submit" name="submit" value="submit"/>     
        </p>
            <input type="hidden" name="action" value="register"/>
    </form>

</div>