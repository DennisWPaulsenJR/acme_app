<div id="heading_banner">
    <a href="../view/index.php"> <img id="logo" src="../images/site/logo.gif" alt="logo image"></a>

    <div id="account_heading">
        <a href="../view/login.php"><img id="account_image" 
                                                 src="../images/site/account.gif"
                        alt="account image"/>
        
        <h4>My account</h4>
            </a> 
        </div>
</div>



